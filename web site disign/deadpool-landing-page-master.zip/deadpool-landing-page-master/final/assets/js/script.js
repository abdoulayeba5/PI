TweenMax.to(".first", 1.5, {
  delay: 1,
  left: "-100%",
  ease: Expo.easeInOut,
});

TweenMax.to(".second", 1.5, {
  delay: .7,
  left: "-100%",
  ease: Expo.easeInOut,
});

TweenMax.to(".third", 1.5, {
  delay: .5,
  left: "-100%",
  ease: Expo.easeInOut,
});
