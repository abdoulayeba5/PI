# Animated Landing Page For A Fashion Theme Website With GSAP
## [Watch it on youtube](https://youtu.be/2ch5enmrwtg)

![Resume cv](/preview.png)