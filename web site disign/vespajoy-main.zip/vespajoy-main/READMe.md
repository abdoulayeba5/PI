# VespaJoy Landing Page

## [Watch it on youtube](https://youtu.be/MKzcgMEoPMw)

![Design Preview](/preview.jpg)
